
using System;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using System.IO;

namespace zpg_start
{
	
	class Povrch 
	{
        
		Microsoft.DirectX.Direct3D.Device device;
        Mesh krajinka = null;
        public int[,] pole;
        public int pocetTrojuhelniku;

		public Povrch(Device dev)
		{
            int n = 128;
            LoadMap map = new LoadMap("mapa128x128.raw", n);  //zadost o nacteni mapy
            pole = map.pole;
            
            pocetTrojuhelniku = (n - 1) * (n - 1) * 2;  //vypocet poctu trojuhelniku
            device = dev;
            Console.WriteLine("Pocet trojuhelniku je: " +pocetTrojuhelniku);	
            krajinka = new Mesh(pocetTrojuhelniku,n*n, MeshFlags.Managed,
                CustomVertex.PositionNormalColored.Format, device);  //vytvoreni instance mesh
           
            //naplneni vertexBufferu vrcholy
            using (VertexBuffer vb = krajinka.VertexBuffer)
            {
                GraphicsStream data = vb.Lock(0, 0, LockFlags.None);
                int barva;
                for (int i = 0; i < n ; i++)
                    for(int j=0;j<n;j++)
                {
                        if(pole[i, j]<40)
                        barva=0x000e7818;
                        else if(pole[i, j]<70)
                           barva = 0x00aaff17;
                        else if(pole[i, j]<140)
                           barva = 0x00efd41e;
                        else if(pole[i, j]<190)
                           barva = 0x00efd41e;
                        else
                        barva = 0x00a16b0c;
                        
                    data.Write(new CustomVertex.PositionNormalColored(i * 2, pole[i, j] / 10.0f, j * 2, 0.0f, 1.0f, 0.0f, barva)); //0x00fcff00
                    
                    }
                vb.Unlock();
            }
            
            short[] indices = new short[pocetTrojuhelniku*3];
            int pocitadloVrcholu = 0;
            int pocitadloTrojuhelniku = 0;
            
            //vypocet indexu vrcholu trojuhelniku
           for (int i = 0; i < ((pocetTrojuhelniku/2+(n-2))); i++) //horni trojuhelniky
            {
                if ((i + 1) % n == 0) { i++; }  //vynechani trojuhelniku na konci kazde rady
                indices[pocitadloVrcholu] = (short)(i);   //horni trojuhelnik 1.bod
           
                pocitadloVrcholu++;
                indices[pocitadloVrcholu] = (short)(n + i);    //horni trojuhelnik 2.bod
            
                pocitadloVrcholu++;
                indices[pocitadloVrcholu] = (short)(i + 1);      ////horni trojuhelnik 3.bod
             
                pocitadloVrcholu++;
                pocitadloTrojuhelniku++;
            }

            for (int i = 0; i < ((pocetTrojuhelniku / 2 + (n - 2))); i++) //horni trojuhelniky
            {
                if ((i + 1) % n == 0) { i++; }  //vynechani trojuhelniku na konci kazde rady
                indices[pocitadloVrcholu] = (short)(i+1);   //horni trojuhelnik 1.bod
              
                pocitadloVrcholu++;
                indices[pocitadloVrcholu] = (short)(n + i);    //horni trojuhelnik 2.bod
            
                pocitadloVrcholu++;
                indices[pocitadloVrcholu] = (short)(i + 1+n);      ////horni trojuhelnik 3.bod
              
                pocitadloVrcholu++;
                pocitadloTrojuhelniku++;
            }
            Console.WriteLine("Nascitany pocet vrcholu je:"+pocitadloVrcholu);
            Console.WriteLine("Nascitany pocet trojuhelniku je:" + pocitadloTrojuhelniku);

            using (IndexBuffer ib = krajinka.IndexBuffer)
            {
                ib.SetData(indices, 0, LockFlags.None);
            }

         krajinka.ComputeNormals();  //vypocet normal automaticky tridou mesh
         
		}

        public void Render()
		{
            krajinka.DrawSubset(0);  //Vykresleni celeho meshe
		}
	}
}
