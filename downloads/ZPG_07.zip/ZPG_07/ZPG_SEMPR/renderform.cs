
using System;
using System.Windows.Forms;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using System.Threading;
using System.Drawing;
using D3D = Microsoft.DirectX.Direct3D;
using D3I = Microsoft.DirectX.DirectInput;
using Microsoft.DirectX.DirectInput;


namespace zpg_start
{

    public class RenderForm : System.Windows.Forms.Form
    {
        private Porost pokusnejPorost = null;

        private Boolean BlikaniScore = false;
        private int pocetBlikuScore = 60;
        private int initPocetBlikuScore = 60;
        private float generovaneX;
        private float generovaneZ;
        private float skok = 0;
        private int ZnamenkoSkoku = 1;
        private bool mouseInvert;
        private bool isConsole;
        private bool lightsOn = true;
        private D3I.Device keyboard;
        private D3I.Device mouse;
        private const int velikostMapy = 128;
        private int rychlostChuze = 3;
        private D3D.Device device = null;
        private Povrch box = null;
        private Kostka kostka = null;
        private kerik krovi = null;
        private Porost travicka = null;
        private Teleport teleport = null;
        //  private Sroub sroub = null;


        private int PocetPorostu = 100;
        private Vector3[] pozicePorostu = new Vector3[100];
        private Porost[] porost = new Porost[100];

        private int pocetSroubu = 10;
        private Sroub[] sroub = new Sroub[10];
        private Vector3[] poziceSroubu = new Vector3[10];

        private Microsoft.DirectX.Direct3D.Font font;
        private Microsoft.DirectX.Direct3D.Font font2;
        private Microsoft.DirectX.Direct3D.Font c;
        private int pocetZobrazeniMlhy = 100;
        private Boolean zobrazeniMlhy = false;
        private Random R = new Random();
        private Material material;
        public long start = 0;
        public long stop = 0;
        public FPSCounter pocitadloFPS2;
        public double FPS;
        public float rotace;
        public float skutecnyUhel = 0.001f;
        public float skutecneZ = 128;
        public float skutecneX = 128;
        public float skutecneY = 9;
        public float startX = 128;
        public float startY = 9;
        public float startZ = 128;
        public float startRotace = 0.001f;
        public float poziceMysiX2;
        public float poziceMysiY2;
        private float camFov = (float)Math.PI / 4;
        private float camNear = 0.5f;
        private float camFar = 200f;
        private float azimuth;
        private float zenith;
        private const float vyskaPostavy = 1.95f;
        private Boolean jeBaterka = false;
        PositionDiscover ps = null;
        private Konzole con;
        private String zprava;

        public RenderForm()
        {
            this.ClientSize = new System.Drawing.Size(640, 480);				/// velikost okna
            this.FormBorderStyle = FormBorderStyle.FixedSingle;					/// styl ramecku okna
            this.MaximizeBox = false;											/// minim. a maxim. tlacitko schovane
            this.MinimizeBox = false;


        }

        public void InitDevices()
        {
            //create keyboard device.
            keyboard = new D3I.Device(SystemGuid.Keyboard);
            if (keyboard == null) throw new Exception("No keyboard found.");

            //create mouse device.
            mouse = new D3I.Device(SystemGuid.Mouse);
            if (mouse == null)
            {
                throw new Exception("No mouse found.");
            }
            //set cooperative level.
            keyboard.SetCooperativeLevel(
                this,
                CooperativeLevelFlags.NonExclusive |
                CooperativeLevelFlags.Background);

            mouse.SetCooperativeLevel(
                this,
                CooperativeLevelFlags.Exclusive |
                CooperativeLevelFlags.Foreground);

        }

        private bool D3DInit()
        {
            try
            {
                PresentParameters param = new PresentParameters();
                param.Windowed = true;											/// chceme pustit v okne
                param.SwapEffect = SwapEffect.Discard;							/// pri preklapeni bufferu nebudou ovlivneny ostatni buffery
                param.EnableAutoDepthStencil = true;
                param.SwapEffect = SwapEffect.Copy;
                param.AutoDepthStencilFormat = DepthFormat.D16;
                device = new D3D.Device(0,											/// vytvoreni zarizeni na defaultnim adapteru
                            D3D.DeviceType.Hardware,								/// pouziva se HW rasterizace
                            this,												/// okno do ktereho se bude kreslit
                            CreateFlags.SoftwareVertexProcessing,				/// softwarove zpracovani vrcholu
                            param);												/// dalsi parametry
                box = new Povrch(device);
                // kostka = new Kostka(device);
                krovi = new kerik(device);
                travicka = new Porost(device);
                teleport = new Teleport(device);

                material = new Material();
                material.Diffuse = System.Drawing.Color.White;  //nastaveni barevnych vlastnosti materialu
                material.Specular = System.Drawing.Color.White;
                material.Ambient = System.Drawing.Color.White;
                material.SpecularSharpness = 20;

                font = new Microsoft.DirectX.Direct3D.Font(device, new System.Drawing.Font(System.Drawing.FontFamily.GenericMonospace, 10));
                font2 = new Microsoft.DirectX.Direct3D.Font(device, new System.Drawing.Font(System.Drawing.FontFamily.GenericMonospace, 20, FontStyle.Bold));
                c = new Microsoft.DirectX.Direct3D.Font(device, new System.Drawing.Font(FontFamily.GenericSansSerif, 500.0f, FontStyle.Bold));
                pocitadloFPS2 = new FPSCounter(200);  //vytvoreni pocitadla FPS s pameti 200 hodnot z duvodu plynulosti pohybu
                ps = new PositionDiscover(box.pole);
                skutecneY = box.pole[64, 64] / 10f + vyskaPostavy;
                con = new Konzole(device);
                this.InitDevices();
                startRotace = 0.1f;
                azimuth = 0.1f;
                Random R = new Random();
                for (int i = 0; i < 10; i++)
                {
                    generovaneX = R.Next((velikostMapy - 1) * 2) + 0.001f;
                    generovaneZ = R.Next((velikostMapy - 1) * 2) + 0.001f;

                    poziceSroubu[i] = new Vector3(generovaneX, ps.vypoctiVysku(generovaneX / 2, generovaneZ / 2) / 10 + 1f, generovaneZ);
                    sroub[i] = new Sroub(device);
                }
                for (int i = 0; i < PocetPorostu; i++)
                {
                    generovaneX = R.Next((velikostMapy - 1) * 2) + 0.001f;
                    generovaneZ = R.Next((velikostMapy - 1) * 2) + 0.001f;
                    pozicePorostu[i] = new Vector3(generovaneX, ps.vypoctiVysku(generovaneX / 2, generovaneZ / 2) / 10 + 1f, generovaneZ);
                    porost[i] = new Porost(device);
                }
                pokusnejPorost = new Porost(device);
                return true;
            }
            catch (DirectXException e)											/// pokud doslo k vyjimce vrat FALSE
            {
                Console.WriteLine(e);
                return false;
            }
        }


        private void Render()
        {
            stop = Environment.TickCount;  //pocita od zacatku render az do dalsiho zacatku render

            pocitadloFPS2.addTime(1 / (double)((stop - start) * 10e-4));  //vlozeni trvani jednoho snimku

            start = Environment.TickCount;
            if (!isConsole) this.Movements();
            FPS = pocitadloFPS2.actualFPS();  //vraceni fps z posledich n snimku
            device.Clear(ClearFlags.Target | ClearFlags.ZBuffer, System.Drawing.Color.Black, 1, 0);		/// vycisti pamet hloubky a barev
            device.BeginScene();												/// zacatek sceny
            device.RenderState.CullMode = Cull.None;							/// orezavani odvracenych sten je vypnuto
            device.RenderState.Lighting = true;								/// osvetleni je vypnuto
            device.RenderState.FillMode = FillMode.Solid;					/// zpusob vykresleni - opuze cary
            device.RenderState.NormalizeNormals = true;

            double phase = Environment.TickCount / 18000.0;  //vypocet faze svetla

            device.Lights[0].Type = LightType.Directional;
            if (!lightsOn) //prenastaveni svetla z dynamickeho na fixni
            {
                device.Lights[0].Direction = new Vector3(120, 40, 120);
            }
            else
            {
                device.Lights[0].Direction = new Vector3(velikostMapy, (float)Math.Sin(phase) * 200, (float)Math.Cos(phase) * 200);
            } device.Lights[0].Diffuse = System.Drawing.Color.White;				/// nastaveni barvy svetla
            device.Lights[0].Enabled = true;
            device.Lights[0].Update();


            float lightZenith = -this.zenith;
            lightZenith += (float)(Math.PI / 180);
            float sinA = (float)Math.Sin(-this.azimuth);
            float cosA = (float)Math.Cos(-this.azimuth);
            float sinZ = (float)Math.Sin(lightZenith);
            float cosZ = (float)Math.Cos(lightZenith);
            float dirX = sinA * cosZ;
            float dirZ = cosA * cosZ;
            float dirY = -(float)Math.Sqrt(dirX * dirX + dirZ * dirZ) * sinZ;


            device.Lights[2].Direction = new Vector3(dirX, dirY, dirZ);
            device.Lights[2].Type = LightType.Spot;
            device.Lights[2].Position = new Vector3((float)skutecneX, skutecneY + 1f, (float)skutecneZ); //nastaveni pozice svetla stejne jako pozice kamery			
            device.Lights[2].Diffuse = System.Drawing.Color.Blue;
            device.Lights[2].Specular = System.Drawing.Color.Blue;
            device.Lights[2].Ambient = System.Drawing.Color.Blue;
            device.Lights[2].Attenuation0 = 1;
            device.Lights[2].InnerConeAngle = (0.5F);
            device.Lights[2].OuterConeAngle = (0.9F);
            device.Lights[2].Falloff = 1;
            device.Lights[2].Range = 20;
            device.Lights[2].Enabled = jeBaterka;
            device.Lights[2].Update();




            device.RenderState.Ambient = System.Drawing.Color.FromArgb(90, 90, 90);  //aby bylo stale neco videt
            device.Transform.Projection = Matrix.PerspectiveFovLH(camFov, (float)this.ClientSize.Width / this.ClientSize.Height, camNear, camFar);

            device.Transform.View = Matrix.Identity;
            device.Transform.View *= Matrix.RotationY((float)startRotace);  //rotace startu kvuli vypoctu trojuhelniku
            device.Transform.View *= Matrix.Translation(-skutecneX, -skutecneY, -skutecneZ);
            device.Transform.View *= Matrix.RotationY(azimuth);
            device.Transform.View *= Matrix.RotationX(zenith);
            skutecnyUhel = azimuth;

            startRotace = 0;  //vynulovani startovnich hodnot 

            skutecnyUhel = skutecnyUhel % ((float)(2 * Math.PI));  //korigovani uhlu proti preteceni promenne

            device.Transform.World = Matrix.Identity;							/// nastaveni matice objektu

            box.Render();
            teleport.Render(100f, ps.vypoctiVysku(100f, 100f) / 10f, 100f);
            krovi.Render();

            for (int i = 0; i < PocetPorostu; i++)
                porost[i].Render(pozicePorostu[i].X, pozicePorostu[i].Y, pozicePorostu[i].Z);

            int nahodne = R.Next();

            skok = skok + ZnamenkoSkoku * (0.01f * (float)(FPS / 10));
            if (skok > 1 || skok < 0) ZnamenkoSkoku = -1 * ZnamenkoSkoku;
            for (int i = 0; i < 10; i++)
            {
                if (sroub[i] != null)
                {
                    sroub[i].Render(poziceSroubu[i].X, poziceSroubu[i].Y + skok, poziceSroubu[i].Z - 1f);
                }
                if (sroub[i] != null & Math.Abs(skutecneX - poziceSroubu[i].X) < 0.5f && Math.Abs(skutecneZ - poziceSroubu[i].Z) < 0.5f)
                {
                    sroub[i] = null;
                    pocetSroubu -= 1;
                    BlikaniScore = true;
                }
            }
            //vypis textu o pozici, FPS, a rychlosti chuze ve vrchni casti okna
            if (!isConsole)
            {
                font.DrawText(null,
                            "FPS:" + FPS + "\n" + "�hel:" + skutecnyUhel + " PI" + "\nSkute�n� -Z: " + skutecneZ + "\nSkute�n� X: " + skutecneX + "\nSkute�n� Y: " + skutecneY +
                            "\nrychlost pohybu: " + rychlostChuze + " m/s",
                            10,
                            20,
                            System.Drawing.Color.LightBlue);
                font.DrawText(null, zprava,

               200,
                          200,
                          System.Drawing.Color.Red);
                if (pocetBlikuScore % 20 < 10 || pocetBlikuScore == initPocetBlikuScore)
                {
                    font2.DrawText(null, "" + (10 - pocetSroubu),
                     600, 20, System.Drawing.Color.Blue);
                }
                if (BlikaniScore == true)
                    pocetBlikuScore--;
                if (pocetBlikuScore == 0 && BlikaniScore == true)
                {
                    pocetBlikuScore = initPocetBlikuScore;
                    BlikaniScore = false;
                }

            }
            device.Material = material;

            if (isConsole)
                con.kresli_konzoli();
            if (zobrazeniMlhy)
            {
                for (int i = 0; i < 10; i++)
                {
                    c.DrawText(null, "I", new System.Drawing.Point(-100 + i * 76, -135), Color.FromArgb((0 + 5 * pocetZobrazeniMlhy / 2), 255, 255, 255));

                }
                if (pocetZobrazeniMlhy > 0)
                { pocetZobrazeniMlhy--; }
                else
                {
                    zobrazeniMlhy = false;
                    pocetZobrazeniMlhy = 100;
                }
            }
            device.EndScene();													/// konec sceny
            device.Present();
            if (Math.Abs(skutecneX - 100f) < 0.5f && Math.Abs(skutecneZ - 100f) < 0.5f)
            {
                teleportace(R);
            }

        }

        private void teleportace(Random R)
        {
            skutecneX = 10 + R.Next(235);
            skutecneZ = 10 + R.Next(235);
            skutecneY = ps.vypoctiVysku(skutecneX / 2, skutecneY / 2) / 10F + vyskaPostavy;
            zobrazeniMlhy = true;
        }

        private void posunKameruVpred(float uhel, int znamenko)
        {
            float predpocteneZ = skutecneZ + (float)(Math.Cos(uhel) * (float)(rychlostChuze / FPS)); ;
            float predpocteneX = skutecneX - (float)(Math.Sin(uhel) * (float)(rychlostChuze / FPS));

            //test na opusteni povrchu
            if (((predpocteneX / 2) < 1) || (((predpocteneX / 2)) >= (velikostMapy - 2)) || ((predpocteneZ / 2) < 1) || ((predpocteneZ / 2) >= (velikostMapy - 2)))
            {
                Console.Beep();  //v pripade ze jsme priliz blizko
                zprava = "Dosahl jste okraje mapy!";
            }
            else
            {
                skutecneZ = predpocteneZ;
                skutecneX = predpocteneX;
                zprava = "";
            }
            skutecneY = ps.vypoctiVysku(skutecneX / 2, skutecneZ / 2) / 10F + vyskaPostavy;
        }

        private void posunKameruVbok(float uhel, int znamenko)
        {
            float predpocteneZ = skutecneZ - (float)(Math.Cos(uhel) * (float)(rychlostChuze / FPS)); ;
            float predpocteneX = skutecneX + (float)(Math.Sin(uhel) * (float)(rychlostChuze / FPS));


            if (((predpocteneX / 2) < 1) || (((predpocteneX / 2)) >= (velikostMapy - 2)) || ((predpocteneZ / 2) < 1) || ((predpocteneZ / 2) >= (velikostMapy - 2)))
            {
                Console.Beep();
                zprava = "Dosahl jste okraje mapy!";
            }
            else
            {
                skutecneZ = predpocteneZ;
                skutecneX = predpocteneX;
                zprava = "";
            }
            skutecneY = ps.vypoctiVysku(skutecneX / 2, skutecneZ / 2) / 10f + vyskaPostavy;
        }


        private void Movements()
        {

            try
            {
                keyboard.Acquire();
                mouse.Acquire();
                Key[] keys = null;
                foreach (Key k in keyboard.GetPressedKeys())
                {
                    keys = keyboard.GetPressedKeys();

                    if (k == Key.W)
                    {
                        posunKameruVpred(skutecnyUhel, 1);
                    }

                    if (k == Key.S)
                    {
                        posunKameruVpred(skutecnyUhel - (float)Math.PI, -1);
                    }
                    if (k == Key.A)
                    {
                        posunKameruVbok(skutecnyUhel - (float)Math.PI / 2, -1);
                    }
                    if (k == Key.D)
                    {
                        posunKameruVbok(skutecnyUhel + (float)Math.PI / 2, 1);
                    }





                }
                MouseState ms = mouse.CurrentMouseState;
                azimuth -= (float)ms.X / this.ClientSize.Width;
                if (mouseInvert) zenith += (float)ms.Y / this.ClientSize.Height;
                else zenith -= (float)ms.Y / this.ClientSize.Height;
                if (zenith > 1.5f) zenith = 1.5f;
                if (zenith < -1.5f) zenith = -1.5f;

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }

        }

        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            if (isConsole)
            {
                if (((int)e.KeyChar) == 13)
                {
                    switch (con.odesliPrikaz())
                    {
                        case 1: this.Close(); break;
                        case 2: lightsOn = false; break;
                        case 3: lightsOn = true; break;
                        case 4: jeBaterka = true; break;
                        case 5: jeBaterka = false; break;
                        case 6: teleportace(R); break;
                    }
                }
                else
                    con.pridejPrikaz(e.KeyChar);
            }
            else
            {
                if (char.ToLower(e.KeyChar).Equals('f')) jeBaterka = !jeBaterka;
                if (char.ToLower(e.KeyChar).Equals('u')) mouseInvert = !mouseInvert;
                if (char.ToLower(e.KeyChar).Equals('l')) lightsOn = !lightsOn;
                if (char.ToLower(e.KeyChar).Equals('b'))
                {
                    if (rychlostChuze == 3) rychlostChuze = 20;
                    else rychlostChuze = 3;
                }
                if (e.KeyChar.Equals((char)27)) this.Close();
            }
            if (char.ToLower(e.KeyChar).Equals('`'))
            {
                isConsole = !isConsole;
                con.vymazPrikazovouRadku();
            }
        }

        static void Main()
        {
            RenderForm frm = new RenderForm();									/// vytvoreni formulare
            if (frm.D3DInit())													/// pokud se podari inicializovat d3d
            {
                frm.Show();														/// zobrazeni formulare 

                while (frm.Created)												/// a dokud formular existuje
                {


                    frm.Render();												/// vykreslovat scenu
                    Application.DoEvents();
                    /// a zpracovavat zpravy
                }
            }
        }


    }
}
