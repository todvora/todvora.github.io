using System;
using System.Collections.Generic;
using System.Text;

namespace zpg_start
{
    class PositionDiscover
    {

        public int[,] poleVysek;


        public PositionDiscover(int[,] pole){
            this.poleVysek = pole;    
        }
        public Bod kteryRoh(float x,float y,float z)
        {
            int levyHorniX =(int)Math.Floor(x);  //vypocet dvou nejistych bodu
            int levyHorniY = (int)Math.Ceiling(y);
            int pravyDolniX = (int)Math.Ceiling(x);
            int pravyDolniY = (int)Math.Floor(y);
            float vzdalenost1=(float)Math.Sqrt((x-levyHorniX)*(x-levyHorniX)+(y-levyHorniY)*(y-levyHorniY));
            float vzdalenost2 =(float) Math.Sqrt((x - pravyDolniX) * (x - pravyDolniX) + (y - pravyDolniY) * (y - pravyDolniY));
            
            //na zaklade vzdalenosti ke kazdemu z nich urcim ktery je ten treti do trojuhelnika
            if (vzdalenost1 < vzdalenost2)
            {
                return new Bod(levyHorniX, levyHorniY, poleVysek[levyHorniX, levyHorniY]);

            }
            else
            {
                return new Bod(pravyDolniX, pravyDolniY, poleVysek[pravyDolniX, pravyDolniY]);
            }
        }

        public float vypoctiVysku(float xDalsihoKroku, float yDalsihoKroku)
        {

            if (xDalsihoKroku % 1 == 0)
            {
                xDalsihoKroku = xDalsihoKroku + 0.001f;
            }
            if (yDalsihoKroku % 1 == 0)
            {
                yDalsihoKroku = yDalsihoKroku + 0.001f;
            }
            //metoda veme dva body co zna,zjisti si treti do trojuhelnika
            //z nej vypocte plochu a testuje zda bod dany dalsim krokem je nad/pod plochou
            //vraci vysku dalsiho kroku
            float zSouradniceRohu = 1;  
            Bod levyDolni = new Bod((float)Math.Floor(xDalsihoKroku), (float)Math.Floor(yDalsihoKroku), poleVysek[(int)Math.Floor(xDalsihoKroku),(int) Math.Floor(yDalsihoKroku)]);
            Bod pravyHorni = new Bod((float)Math.Ceiling(xDalsihoKroku), (float)Math.Ceiling(yDalsihoKroku), poleVysek[(int)Math.Ceiling(xDalsihoKroku),(int) Math.Ceiling(yDalsihoKroku)]);
            Bod zjistenyRoh = kteryRoh(xDalsihoKroku, yDalsihoKroku, zSouradniceRohu);
            trojuhelnik tri = new trojuhelnik();
            tri.trojuhelnikUpdate(levyDolni, pravyHorni, zjistenyRoh);

            return tri.dopadniNaPovrch(xDalsihoKroku, yDalsihoKroku);
        }
    }
}
