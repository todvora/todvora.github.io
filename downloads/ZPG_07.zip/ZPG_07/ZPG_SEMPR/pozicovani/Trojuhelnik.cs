using System;
using System.Collections.Generic;
using System.Text;

namespace zpg_start
{
    class trojuhelnik
    {
        private float x1;
        private float y1;
        private float z1;
        private float x2;
        private float y2;
        private float z2;
        private float x3;
        private float y3;
        private float z3;
        private float n1;
        private float n2;
        private float n3;
        private float k;
        private const float klesani = 0.01f;

        public void trojuhelnikUpdate(float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3)
        {
            this.x1 = x1;
            this.y1 = y1;
            this.z1 = z1;
            this.x2 = x2;
            this.y2 = y2;
            this.z2 = z2;
            this.x3 = x3;
            this.y3 = y3;
            this.z3 = z3;

            vypoctiNormalu();
            vypoctiKonstantu();
        }

        public void trojuhelnikUpdate(Bod p1,Bod p2,Bod p3)
        {
            this.x1 = p1.getX();
            this.y1 = p1.getY();
            this.z1 = p1.getZ();
            if (p3.getX() == p1.getX())  //rozhodovani o smeru hodinovych rucicek
            {
                this.x2 = p3.getX();
                this.y2 = p3.getY();
                this.z2 = p3.getZ();
                this.x3 = p2.getX();
                this.y3 = p2.getY();
                this.z3 = p2.getZ();
            }
            else
            {
               
                this.x2 = p2.getX();
                this.y2 = p2.getY();
                this.z2 = p2.getZ();
                this.x3 = p3.getX();
                this.y3 = p3.getY();
                this.z3 = p3.getZ();
            }
            vypoctiNormalu();
            vypoctiKonstantu();
        }

        public void vypoctiNormalu()
        {

            float b1 = x2 - x1;   //prvni vektor plochy
            float b2 = y2 - y1;
            float b3 = z2 - z1;

            float a1 = x3 - x1;  //druhy vektor plochy
            float a2 = y3 - y1;
            float a3 = z3 - z1;


            n1 = a2 * b3 - a3 * b2;
            n2 = a3 * b1 - a1 * b3;
            n3 = a1 * b2 - a2 * b1;
        }

        public void vypoctiKonstantu()
        {
            k = n1 * x1 + n2 * y1 + n3 * z1;  //kostanta urcujici zda jsem nad nebo pod plochou
        }

        public bool jeNadPlochou(float xTestovane, float yTestovane, float zTestovane)
        {
            float k2 = xTestovane * n1 + yTestovane * n2 + zTestovane * n3;
            if (k2 > k) return true;
            else return false;
        }

        public String vypisNormalu(){
            return "n = ( " + n1 + " , " + n2 + " , " + n3 + " )";
    }

        public float dopadniNaPovrch(float xStartovni, float yStartovni)
        {



      
            //�bytecny cyklus odstanen,nahrazen jednokrokovym vypoctem

            //while (jeNadPlochou(xStartovni, yStartovni, zDosazene))
            //{
            //    zDosazene -= klesani;
            //}
            //return (zDosazene + klesani);

            return klesani + ((k - xStartovni * n1 - yStartovni * n2) / n3);
        }
    }
}
