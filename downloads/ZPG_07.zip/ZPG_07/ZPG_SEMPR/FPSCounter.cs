using System;
using System.Text;
using System.Collections;

namespace zpg_start
{
    public class FPSCounter
    {
        private Queue fronta=null;  //vytvoreni nove fronty
        private int size;  //velikost fronty
        public FPSCounter(int size)
        {
            this.size = size;
            fronta = new Queue();
        }

        public void addTime(double time)
        {
            if (Double.IsPositiveInfinity(time))
            {
                fronta.Enqueue((double)0);  //osetreni problemu kdy okamzik renderu je tak rychly,ze zaokrouhlenim vyjde na 0,tou pak delime jednicku a vyjde kladne nekonecno
            }
            else
            {
                fronta.Enqueue(time);
            }  //pridani noveho casu trvani snimku
            if (fronta.Count > this.size)  //pokud prvek pridany zvysi pocet prvku ve fronte prez mez,tak se prvni odstrani
            {
                fronta.Dequeue();  //odstraneni prebytecneho prvku
            }
        }

        //aktualFPS vraci bud prumer z poslednich n prvku(n je zadano konstruktorem) nebo pokud jeste neni naplnena fronta,pak jen ty prvky co jsou pridany
            public double actualFPS()
            {
                double sum = 0;
                foreach (double Time in this.fronta) sum += Time;   //prochazeni celou frontou a poscitani casu
                double average = 0;
                average = sum / (double)this.fronta.Count;  //arit. prumer jako vypocet sumy vsech ve fronte deleno poctem
                                return average;
            }
    }
}
