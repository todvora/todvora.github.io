using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using D=Microsoft.DirectX.Direct3D;
using System.Drawing.Drawing2D;
using System.ComponentModel;

namespace zpg_start
{
  class Konzole {
    D.Device device;
    D.Font pozadiKonzole;
    
    D.Font text;
    string cText;
    string jedenPrikaz;
    public static string[] prikaz = new string[7] {  "?", "exit", "lights fixed", "lights dynamic","flashlight on","flashlight off","teleport" };
      public static string[] popis = new string[7] { "?, exit, lights fixed, lights dynamic, flashlight on, flashlight off, teleport",
                                   "**Vypinani aplikace...", 
                                   "**svetla na statickou pozici", 
                                   "**svetla dynamicky", 
                                   "**baterka zapnuta", 
                                   "**baterka vypnuta",
                                    "**teleportace...",
  };
    public const string neznamy_prikaz = "!!neznamy prikaz: ";
    public const string uvodni_znak = ">";
    public const string hlavicka = "--Napi� ? pro n�pov�du--\n";
    
   

    

    public int odesliPrikaz() {
      int pocetPrikazu=-1;
      string comm = jedenPrikaz.Substring(uvodni_znak.Length).Trim().ToLower();
      for (int i = 0; i < prikaz.Length; i++) {
        if (comm.Equals(prikaz[i])) pocetPrikazu = i;
      }
      if (pocetPrikazu != -1) {
        cText += popis[pocetPrikazu] + "\n";
      } else 
        if (comm.Length!=0)
          cText += neznamy_prikaz + comm + "\n";

      this.vymazPrikazovouRadku();
      return pocetPrikazu;
    }

      private int ziskejRadky()
      {
          string[] tmp = cText.Split("\n".ToCharArray());
          return tmp.Length - 1;
      }

    public void pridejPrikaz(char ch) {
      if ((((int)ch) == 8) && (jedenPrikaz.Length > uvodni_znak.Length)) {
        jedenPrikaz = jedenPrikaz.Substring(0, jedenPrikaz.Length - 1);
      } else
        if (((((int)ch)>31))&&(((int)ch)<126))
          jedenPrikaz += ch;
    }

    public void vymazPrikazovouRadku() {
      jedenPrikaz = uvodni_znak;
    }

    public void kresli_konzoli() {
      for (int i = 0; i < 21; i++) {
       pozadiKonzole.DrawText(null, "I", new System.Drawing.Point(-25+(i*31), -60), Color.FromArgb(150,0,0,40));
      
      }
 

        text.DrawText(null, cText+jedenPrikaz, new System.Drawing.Point(10, 160 - (this.ziskejRadky() * 16)), Color.DarkKhaki);
    }
      public Konzole(Device dev)
      {
          this.device = dev;

          pozadiKonzole = new Microsoft.DirectX.Direct3D.Font(dev, new System.Drawing.Font(FontFamily.GenericSansSerif, 200.0f, FontStyle.Bold));
          text = new Microsoft.DirectX.Direct3D.Font(dev, new System.Drawing.Font(FontFamily.GenericSansSerif, 10.0f));
          cText = hlavicka;
          jedenPrikaz = uvodni_znak;
      }
  }
}
