using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace zpg_start
{
    class LoadMap
    {
        public int[,] pole = null;  //vytvoreni pole pro mapu
        public LoadMap(String nazevSouboru,int rozmer)
        {
            int n = rozmer;

            try
            {
                FileStream ctenar = new FileStream(nazevSouboru, FileMode.Open);  //otevreni souboru pro cteni
                pole = new int[n, n];  //nainicializovani pole

                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        pole[i, j] = ctenar.ReadByte();  //Cteni byte po byte a ukladani do pole

                    }
                }


                ctenar.Close();
            }
            catch (Exception e)
            {

                Console.WriteLine("Chyba nacitani souboru : "+ e.ToString());
                Console.WriteLine("-----------------------");
                Console.WriteLine("Ukoncete aplikaci zavrenim konzole") ;
                Console.Read();
               
            }
        }
    }
}
