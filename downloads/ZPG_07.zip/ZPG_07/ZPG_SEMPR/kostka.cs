using System;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;

namespace zpg_start
{
	
	class Kostka 
	{
		Microsoft.DirectX.Direct3D.Device device;
		VertexBuffer vb = null;

	
		public Kostka(Device dev)
		{
			device=dev;
			vb = new VertexBuffer(typeof(CustomVertex.PositionOnly),	/// buffer obsahuje pouze souradnice
						10,												/// celkem 10 bodu 			
						device,											/// zarizeni pro ktere je buffer vytovren
						Microsoft.DirectX.Direct3D.Usage.WriteOnly,		/// do bufferu se bude pouze zapisovat
						CustomVertex.PositionOnly.Format,				/// format vrcholu - pouze souradnice 
						Pool.Managed);									/// jakym zpusobem je VB zpravovan
			CustomVertex.PositionOnly[] v = (CustomVertex.PositionOnly[])vb.Lock(0,0);
																		/// uzamceni VB a ziskani pole
			v[0] = new CustomVertex.PositionOnly(-1,-1,-1);				/// naplneni VB souradnicemi vrcholu
			v[1] = new CustomVertex.PositionOnly( 1,-1,-1);
			v[2] = new CustomVertex.PositionOnly(-1, 1,-1);
			v[3] = new CustomVertex.PositionOnly( 1, 1,-1);
			v[4] = new CustomVertex.PositionOnly(-1, 1, 1);
			v[5] = new CustomVertex.PositionOnly( 1, 1, 1);
			v[6] = new CustomVertex.PositionOnly(-1,-1, 1);
			v[7] = new CustomVertex.PositionOnly( 1,-1, 1);
			v[8] = new CustomVertex.PositionOnly(-1,-1,-1);
			v[9] = new CustomVertex.PositionOnly( 1,-1,-1);
			vb.Unlock();												/// odemknuti VB 
		}


		public void Render()
		{
            device.Transform.World =  Matrix.Translation(100, 6,100);
			device.SetStreamSource(0, vb, 0);							/// nastaveni zdroje dat
			device.VertexFormat = CustomVertex.PositionOnly.Format;		/// format dat
			device.DrawPrimitives(PrimitiveType.TriangleStrip, 0, 8);	/// vykresleni VB jako strip
		}

	}

}
