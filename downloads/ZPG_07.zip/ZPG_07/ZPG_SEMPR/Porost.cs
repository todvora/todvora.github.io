using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using D3D = Microsoft.DirectX.Direct3D;

namespace zpg_start
{
	class Porost 
	{


        private D3D.Device device;
    
        private Material material;
        ArrayList verticeslist = new ArrayList();

        private Mesh spacemesh;
        private Material[] spacemeshmaterials;
        private Texture[] spacemeshtextures;
        private float spacemeshradius;
        private float scaling = 2f;
        private Random R = new Random();
        private float nahodnaRotace=0;
		public Porost(Device dev)
		{
            this.device = dev;
            LoadTexturesAndMaterials();
            LoadMeshes();
            nahodnaRotace = (float)(R.NextDouble() * 4);

		}

        private void LoadTexturesAndMaterials()
        {
            material = new Material();

            material.Diffuse = Color.Red;
            material.Ambient = Color.White;

            device.Material = material;

            // scenerytexture = TextureLoader.FromFile(device, "texturemap.jpg");
        }




        private void LoadMesh(string filename, ref Mesh mesh, ref Material[] meshmaterials, ref Texture[] meshtextures, ref float meshradius)
        {
            ExtendedMaterial[] materialarray;
            mesh = Mesh.FromFile(filename, MeshFlags.Managed, device, out materialarray);

            if ((materialarray != null) && (materialarray.Length > 0))
            {
                meshmaterials = new Material[materialarray.Length];
                meshtextures = new Texture[materialarray.Length];

                for (int i = 0; i < materialarray.Length; i++)
                {
                    meshmaterials[i] = materialarray[i].Material3D;
                    meshmaterials[i].Ambient = meshmaterials[i].Diffuse;

                    if ((materialarray[i].TextureFilename != null) && (materialarray[i].TextureFilename != string.Empty))
                    {
                        meshtextures[i] = TextureLoader.FromFile(device, materialarray[i].TextureFilename);
                    }
                }
            }

            mesh = mesh.Clone(mesh.Options.Value, CustomVertex.PositionNormalTextured.Format, device);
            mesh.ComputeNormals();

            VertexBuffer vertices = mesh.VertexBuffer;
            GraphicsStream stream = vertices.Lock(0, 0, LockFlags.None);
            Vector3 meshcenter;
            meshradius = Geometry.ComputeBoundingSphere(stream, mesh.NumberVertices, mesh.VertexFormat, out meshcenter) * scaling;
            vertices.Unlock();
        }

        private void LoadMeshes()
        {
            LoadMesh("rostlina.x", ref spacemesh, ref spacemeshmaterials, ref spacemeshtextures, ref spacemeshradius);
        }

        public void DrawMesh(Mesh mesh, Material[] meshmaterials, Texture[] meshtextures,float x,float y,float z)
        {
            
            for (int i = 0; i < meshmaterials.Length; i++)
            {
                device.Material = meshmaterials[i];
                device.SetTexture(0, meshtextures[i]);
                scaling = 40 / y;
                device.Transform.World = Matrix.Scaling(new Vector3(scaling,scaling,scaling))*Matrix.RotationZ(nahodnaRotace)*Matrix.RotationX(-(float)Math.PI/2 -0.1f)*Matrix.Translation(x, y-1.1f, z);
                mesh.DrawSubset(i);
            }
        }



        public void Render(float x,float y,float z)
		{
            DrawMesh(spacemesh, spacemeshmaterials, spacemeshtextures,x,y,z);
		}
	}
}
