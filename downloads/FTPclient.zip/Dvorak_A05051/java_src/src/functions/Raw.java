package functions;

import java.io.IOException;

/**
 * Trida pro praci s FTP, odesle prikaz jako textovy retezec
 * @author Tomas Dvorak, A05051
 */
public class Raw extends Thread {

    Connect connect;
    String expr;
    String response;

    /**
     * Konstruktor, uklada informace o spojeni
     * @param c
     * @param expr
     */
    public Raw(Connect c, String expr) {
        this.connect = c;
        this.expr = expr;
    }

    /**
     * vykonna metoda, odesle raw command
     * @throws java.io.IOException
     */
    public synchronized void vykonej() throws IOException {
        connect.sendLine(expr);
        this.response = connect.readLine();

    }
}
