
package functions;

import java.io.IOException;



/**
 * Trida pro praci s FTP, odpojuje od serveru ftp
 * @author Tomas Dvorak, A05051
 */
public class Quit{

    Connect connect;
    
    /**
     * Konstruktor, uklada informace o spojeni
     * @param c
     */
    public Quit(Connect c){
        this.connect=c;
    }
    
   
    /**
     * vykonna metoda
     * @return zprava o odpojeni
     * @throws java.io.IOException
     */
    public synchronized String  vykonej() throws IOException{
    
        try
        {
            if(connect.socket!=null)
            connect.sendLine("QUIT");
        }
        finally
        {
            
            connect.socket = null;
             return connect.readLine();
        }
    
    }
    
}
