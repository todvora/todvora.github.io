package functions;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Trida pro praci s FTP, stahne soubor ze serveru
 * @author Tomas Dvorak, A05051
 */
public class Retr extends Thread {

    Connect connect;
    String response = "";
    String puvodni;
    String nova;
    private static final int TIMEOUT = 2000;

    /**
     * Konstruktor,ulozi informace o spojeni, ktery soubor stahnout a kam
     * @param c
     * @param puvodni
     * @param nova
     */
    public Retr(Connect c, String puvodni, String nova) {
        this.connect = c;
        this.puvodni = puvodni;
        this.nova = nova;
    }

    /**
     * Start vlakna
     */
    @Override
    public void run() {
        try {
            retr(puvodni, nova);
        } catch (IOException ex) {
            Logger.getLogger(Retr.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Samotna metoda pro stazeni souboru
     * @param origFile
     * @param filePath
     * @return true/false podle toho zda se povede stazeni souboru
     * @throws java.io.IOException
     */
    public synchronized boolean retr(String origFile, String filePath) throws IOException {

        connect.sendLine("PASV");
        this.response = connect.readLine();
        if (!this.response.startsWith("227")) {
            throw new IOException("could not request passive mode: " + this.response);
        }

        String ip = null;
        int port = -1;
        int opening = this.response.indexOf('(');
        int closing = this.response.indexOf(')', opening + 1);
        if (closing > 0) {
            String dataLink = this.response.substring(opening + 1, closing);
            StringTokenizer tokenizer = new StringTokenizer(dataLink, ",");
            try {
                ip = tokenizer.nextToken() + "." + tokenizer.nextToken() + "." + tokenizer.nextToken() + "." + tokenizer.nextToken();
                port = Integer.parseInt(tokenizer.nextToken()) * 256 + Integer.parseInt(tokenizer.nextToken());
            } catch (Exception e) {
                throw new IOException("received bad data link information: " + this.response);
            }
        }

        connect.bin();


        Socket dataSocket = new Socket(ip, port);
        connect.inputReader = new InputStreamReader(dataSocket.getInputStream());
        connect.sendLine("RETR " + origFile);


        this.response = connect.readLine();
        if (!this.response.startsWith("150")) {
            throw new IOException("was not allowed to send the file: " + this.response);
        }


        int a = 0;
        int wait = 5;
        while (connect.inputReader.ready() != true) {
            try {
                wait(wait);
            } catch (Exception e) {
                throw new IOException("Fail: " + e.getMessage());
            }

            if (a >= TIMEOUT) {
                throw new IOException("Timeout");

            } else {
                a += wait;
            }
        }

        if (connect.inputReader.ready()) {
            FileOutputStream outFile = new FileOutputStream(filePath);


            int i;

            BufferedInputStream bis = new BufferedInputStream(dataSocket.getInputStream());

            while ((i = bis.read()) != -1) {
                outFile.write(i);
            }

            if (dataSocket.isClosed() == false) {
                dataSocket.close();
            }
            outFile.close();
        }


        a = 0;
        while (connect.reader.ready() != true) {
            try {
                wait(wait);
            } catch (Exception e) {
                throw new IOException("Fail: " + e.getMessage());
            }
            if (a >= TIMEOUT) {
                throw new IOException("Timeout");
            } else {
                a += wait;
            }
        }

        if (connect.reader.ready() == true) {
            this.response = connect.readLine();

            if (!this.response.startsWith("226")) {
                throw new IOException("not allowed to recieve LIST: " + this.response);
            }
        }

        return this.response.startsWith("226");
    }
}
