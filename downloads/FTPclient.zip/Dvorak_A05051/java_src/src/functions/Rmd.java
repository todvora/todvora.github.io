
package functions;

import java.io.IOException;


/**
 * Trida pro praci s FTP, smaze slozku na serveru
 * @author Tomas Dvorak, A05051
 */
public class Rmd extends Thread{

    Connect connect;
    String slozka;
    String response;
    
    /**
     * Konstruktor, uklada informace o spojeni a slozce co bude smazana
     * @param c
     * @param slozka
     */
    public Rmd(Connect c,String slozka){
        this.connect=c;
        this.slozka=slozka;
    }
    

    /**
     * vykonna metoda mazani
     * @return true/false podle toho jak se povede mazani
     * @throws java.io.IOException
     */
    public synchronized boolean vykonej() throws IOException{
      connect.sendLine("RMD "+slozka);
        this.response = connect.readLine();
        
        if (this.response.startsWith("250"))
        {
            return true;
        }
        else
        {
            return false;
        }
    
    }
}
