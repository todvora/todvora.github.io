package functions;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.StringTokenizer;

/**
 * Trida pro praci s FTP, prenese soubor na server
 * @author Tomas Dvorak, A05051
 */
public class Stor extends Thread {

    Connect connect;
    String response = "";
    String nazev;
    String cesta;
  
    /**
     * Konstruktor, uklada informace o spojeni, jaky soubor ulozit, a kde ho najit
     * @param c
     * @param nazev
     * @param cesta
     */
    public Stor(Connect c, String nazev, String cesta) {
        this.connect = c;
        this.nazev = nazev;
        this.cesta = cesta;
    }

    /**
     * Start vlakna
     */
    @Override
    public void run() {
        try {
            File file = new File(cesta);


            stor(new FileInputStream(file), file.getName(), file.length());
        } catch (IOException ex) {
            connect.pridejZpravu(ex.toString());
        }

    }

    /**
     * vykonna metoda ukladani
     * @param souborStream
     * @param filename
     * @param fileSize
     * @return true/false podle toho zda se povede ulozeni na server
     * @throws java.io.IOException
     */
    public synchronized boolean stor(InputStream souborStream, String filename, long fileSize)
            throws IOException {

        connect.sendLine("PASV");
        this.response = connect.readLine();
        if (!this.response.startsWith("227")) {
            throw new IOException("could not request passive mode: " + this.response);
        }

        String ip = null;
        int port = -1;
        int opening = this.response.indexOf('(');
        int closing = this.response.indexOf(')', opening + 1);
        if (closing > 0) {
            String dataLink = this.response.substring(opening + 1, closing);
            StringTokenizer tokenizer = new StringTokenizer(dataLink, ",");
            try {
                ip = tokenizer.nextToken() + "." + tokenizer.nextToken() + "." + tokenizer.nextToken() + "." + tokenizer.nextToken();
                port = Integer.parseInt(tokenizer.nextToken()) * 256 + Integer.parseInt(tokenizer.nextToken());
            } catch (Exception e) {
                throw new IOException("received bad data link information: " + this.response);
            }
        }
        connect.bin();

        Socket dataSocket = new Socket(ip, port);

        connect.sendLine("STOR " + filename);
        this.response = connect.readLine();
        if (!this.response.startsWith("150")) {
            throw new IOException("was not allowed to send the file: " + this.response);
        }

        BufferedOutputStream output = new BufferedOutputStream(dataSocket.getOutputStream());
        int i;
        while ((i = souborStream.read()) != -1) {
            output.write(i);
        }

        output.flush();
        output.close();
        souborStream.close();
        this.response = connect.readLine();
        return this.response.startsWith("226");
    }
}
