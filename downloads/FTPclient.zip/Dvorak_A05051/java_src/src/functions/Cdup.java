
package functions;

import java.io.IOException;


/**
 * Trida pro praci s FTP, posun o slozku vyse ve stromu
 * @author Tomas Dvorak, A05051
 */
public class Cdup extends Thread{

    Connect connect;
    String response;
    
    /**
     * konstruktor, ziskani udaju o FTP pripojeni
     * @param c
     */
    public Cdup(Connect c){
        this.connect=c;
       
    }
    

    /**
     * vykonna metoda
     * @return true/false podle toho zda se povede zmena adresare
     * @throws java.io.IOException
     */
    public synchronized boolean vykonej() throws IOException{
     connect.sendLine("CDUP");
        this.response = connect.readLine();
        
        if(this.response.startsWith("550"))
        {
            return false;
        }
        else
            return (this.response.startsWith("257"));
    }
    
    
    
}
