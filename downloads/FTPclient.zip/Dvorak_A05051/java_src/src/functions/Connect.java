package functions;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.LinkedList;
import java.util.StringTokenizer;

/**
 * Trida pro praci s FTP, pripojeni, prepinani modu binarni/ascii, odesilani a prijimani prikazu 
 * @author Tomas Dvorak
 */
public class Connect {

    String host;
    int port;
    String user;
    String pass;
    String response;
    private LinkedList frontaZprav;
    private static final String SYSTEM_LINE_SEPARATOR = System.getProperty("line.separator");
    public Socket socket = null;
    public Socket dataSocket = null;
    public InputStreamReader inputReader = null;
    public BufferedReader reader = null;
    public BufferedReader dataReader = null;
    private BufferedWriter writer = null;
    private Object lock = new Object();

    public Connect(String host, int port, String user,
            String pass) throws IOException {
        this.frontaZprav = new LinkedList();
        this.host = host;
        this.port = port;
        this.user = user;
        this.pass = pass;

        if (socket != null) {
            throw new IOException("Is already connected. Disconnect first.");
        }

        socket = new Socket(host, port);
        reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

        String response = readLine();


        if (!response.startsWith("220")) {
            throw new IOException("Error when connecting to the FTP server: " + response);
        }
        sendLine("USER " + user);
        response = readLine();
        sendLine("PASS " + pass);
        response = readLine();
        if (response.startsWith("530") || response.startsWith("500") || response.startsWith("503")) {
            //    pridejZpravu("Neni mozné prihlásit se: "+ response);
            throw new IOException(
                    "Neni mozne prihlasit se: " + response);

        }

    }

    /**
     * precte radku(y) ze vstupniho socketu
     * @return retezec s navracenym kodem ze serveru
     * @throws java.io.IOException
     */
    public synchronized String readLine() throws IOException {
        StringBuffer fileLines = new StringBuffer();

        try {
            String line = null;
            while (!reader.ready()) {
                Thread.sleep(50);
            }
            while (reader.ready()) {
                line = reader.readLine();
                fileLines.append(line + "\n");

            }
        } catch (InterruptedException ex) {
            System.out.println("Chyba vzbuzeni");
        } catch (IOException e) {
            System.out.println("Error reading: " + e.getMessage());
        }
        pridejZpravu("> " + fileLines.toString());
        return fileLines.toString();


    }

    /**
     * odesle prikaz prez socket ftp serveru
     * @param line
     * @throws java.io.IOException
     */
    public void sendLine(String line) throws IOException {
        if (socket == null) {
            throw new IOException("FTP is not connected.");
        }
        try {
            pridejZpravu("< " + line);
            writer.write(line + "\r\n");
            writer.flush();
        } catch (IOException e) {
            socket = null;
            throw e;
        }
    }

    /**
     * prepne na pasivni rezim ftp a pripoji novy dataSocket
     * @return true/false podle toho zda se povede prepnuti do pasivniho modu
     * @throws java.io.IOException
     */
    public boolean pasw() throws IOException {
        synchronized (lock) {
            sendLine("PASV");
            String response = readLine();
            if (!response.startsWith("227")) {
                throw new IOException("PASV: " + response);
            }

            String ip = null;
            int port = -1;
            int opening = response.indexOf('(');
            int closing = response.indexOf(')', opening + 1);
            if (closing > 0) {
                String dataLink = response.substring(opening + 1, closing);
                StringTokenizer tokenizer = new StringTokenizer(dataLink, ",");
                try {
                    ip = tokenizer.nextToken() + "." + tokenizer.nextToken() + "." + tokenizer.nextToken() + "." + tokenizer.nextToken();
                    port = Integer.parseInt(tokenizer.nextToken()) << 8 |
                            Integer.parseInt(tokenizer.nextToken());
                } catch (Exception e) {
                    throw new IOException("PASV: " + response);
                }
            }

            dataSocket = new Socket(ip, port);

        }
        return true;


    }

    /**
     * cte data z dataSocketu
     * @return radka textu pro potreby metody List
     * @throws java.io.IOException
     */
    public String readDataLine() throws IOException {
        if (true) {
            return ((BufferedReader) dataReader).readLine();
        }
        StringBuffer buffer = new StringBuffer();
        int previous = -1;
        int current = -1;
        do {
            int i = dataReader.read();
            if (i == -1) {
                if (buffer.length() == 0) {
                    return null;
                } else {
                    return buffer.toString();
                }
            }
            previous = current;
            current = i;
            if (previous == '\r' && current == '\n') {

                String statement = buffer.toString();

                if (statement.endsWith("Portale RER Shared")) {
                    System.out.println(".");
                }
                return statement;
            } else if (previous == '\r' && current == 0) {
                // Literal new line.
                buffer.append(SYSTEM_LINE_SEPARATOR);
            } else if (current != 0 && current != '\r') {
                buffer.append((char) current);
            }
        } while (true);
    }

    /**
     * prepne prenos dp binarniho rezimu pro prenos dat
     * @return true/false pokud se povedlo prepnuti
     * @throws java.io.IOException
     */
    public synchronized boolean bin() throws IOException {
        sendLine("TYPE I");
        this.response = readLine();
        pridejZpravu("> " + response);
        return (this.response.startsWith("200"));
    }
    
/**
     * prida zpravu do fronty zprav
     * @return retezec se zpravou z/pro ftp server pro potreby logovani
     */
    synchronized void pridejZpravu(String zprava) {
        frontaZprav.addLast(zprava);
    }

    /**
     * vybere zpravu z fronty zprav
     * @return retezec se zpravou z/pro ftp server pro potreby logovani
     */
    public synchronized String vyberZpravu() {
        if (!frontaZprav.isEmpty()) {
            return (String) frontaZprav.removeFirst();
        } else {
            return null;
        }
    }
}
