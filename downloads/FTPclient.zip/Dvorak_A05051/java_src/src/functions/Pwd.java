package functions;

import java.io.IOException;

/**
 * Trida pro praci s FTP, vraci aktualni nazev slozky
 * @author Tomas Dvorak, A05051
 */
public class Pwd {

    Connect connect;

    /**
     * Konstruktor, uklada informace o spojeni
     * @param c
     */
    public Pwd(Connect c) {
        this.connect = c;
    }

    /**
     * vykonna metoda
     * @return retezec s nazvem pracovni slozky
     * @throws java.io.IOException
     */
    public String vykonej() throws IOException {

        connect.sendLine("PWD");
        String dir = null;
        String response = connect.readLine();
        if (response.startsWith("257")) {
            int firstQuote = response.indexOf('\"');
            int secondQuote = response.indexOf('\"', firstQuote + 1);
            if (secondQuote > 0) {
                dir = response.substring(firstQuote + 1, secondQuote);
            }
        }
        return dir;

    }
}
