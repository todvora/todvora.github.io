package functions;

import java.io.IOException;

/**
 * Trida pro praci s FTP, vrati seznam prikazu kterym server rozumi
 * @author Tomas Dvorak
 */
public class Help extends Thread {

    Connect connect;
    String response;

    /**
     * Konstruktor,ulozi informace o pripojeni
     * @param c
     */
    public Help(Connect c) {
        this.connect = c;

    }

    /**
     * Vykonna metoda, odesle prikaz na server
     * @return retezec s napovedou serveru
     * @throws java.io.IOException
     */
    public synchronized String vykonej() throws IOException {
        connect.sendLine("HELP");
        this.response = connect.readLine();
        return response;
    }
}
