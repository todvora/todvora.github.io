package functions;

import java.io.IOException;

/**
 * Trida pro praci s FTP, maze soubor na serveru
 * @author Tomas Dvorak
 */
public class Dele extends Thread {

    Connect connect;
    String soubor;
    String response;

    /**
     * Konstruktor, ulozi nazev slozky a udaje o pripojeni
     * @param c
     * @param soubor
     */
    public Dele(Connect c, String soubor) {
        this.connect = c;
        this.soubor = soubor;
    }

    /**
     * vykonna metoda,odesle prikaz pro smazani souboru
     * @return true/false podle toho zda se smazani povede
     * @throws java.io.IOException
     */
    public synchronized boolean vykonej() throws IOException {

        connect.sendLine("DELE " + soubor);

        this.response = connect.readLine();

        if (this.response.startsWith("250")) {
            return true;
        } else {

            return false;
        }
    }
}
