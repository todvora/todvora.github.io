package functions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Trida pro praci s FTP, odesle prikaz pro vraceni seznamu slozek a souboru
 * @author Tomas Dvorak
 */
public class List {

    Connect connect;

    /**
     * Konsturktor,ulozi udaje o pripojeni
     * @param c
     */
    public List(Connect c) {
        this.connect = c;
    }

    /**
     * vykonna metoda 
     * @return retezec se soubory,slozkami
     * @throws java.io.IOException
     */
    public synchronized String vykonej() throws IOException {
        String retezec = "";
        String response = "";
        ArrayList<String> lines = new ArrayList<String>();

        synchronized (this) {

            connect.pasw();

            connect.sendLine("TYPE A");
            response = connect.readLine();

            connect.sendLine("LIST");
            response = connect.readLine();


            InputStream input = connect.dataSocket.getInputStream();
            connect.dataReader = new BufferedReader(new InputStreamReader(input, "UTF-8"));
            try {
                String line;
                while ((line = connect.readDataLine()) != null) {
                    if (line.length() > 0) {
                        lines.add(line);
                    }
                }
            } catch (IOException e) {

            } finally {
                connect.dataSocket.close();
                response = connect.readLine();
            }


            Iterator itr = lines.iterator();
            while (itr.hasNext()) {
                String element = itr.next().toString();

                retezec = retezec + System.getProperty("line.separator") + element;
            }

        }
        return retezec;

    }
}
