package functions;

import java.io.IOException;

/**
 * Trida pro praci s FTP, zmeni pracovni adresar
 * @author Tomas Dvorak, A05051
 */
public class Cwd {

    Connect connect;
    String slozka;

    /**
     * konstruktor tridy, ulozi pripojeni pro ftp server
     * @param c
     * @param slozka
     */
    public Cwd(Connect c, String slozka) {
        this.connect = c;
        this.slozka = slozka;
    }

    /**
     * vykonna metoda tridy, odesle prikaz pro prepnuti adresare
     * @return true/false podle toho jak se prepnuti povede
     * @throws java.io.IOException
     */
    public synchronized boolean vykonej() throws IOException {

        {
            connect.sendLine("CWD " + slozka);
            String response = connect.readLine();
            return (response.startsWith("250"));
        }

    }
}
