package functions;

import java.io.IOException;

/**
 * Trida pro praci s FTP, vytvari slozku na serveru
 * @author Tomas Dvorak, A05051
 */
public class Mkd{

    Connect connect;
    String slozka;
    String response;

    /**
     * Konstruktor, uklada informace o spojeni
     * @param c
     * @param slozka
     */
    public Mkd(Connect c, String slozka) {
        this.connect = c;
        this.slozka = slozka;
    }

    /**
     * vykonna metoda
     * @return true/false podle toho jak se povede tvoreni slozky
     * @throws java.io.IOException
     */
    public synchronized boolean vykonej() throws IOException {
        connect.sendLine("MKD " + slozka);
        this.response = connect.readLine();

        if (this.response.startsWith("550")) {
            return false;
        } else {
            return (this.response.startsWith("257"));
        }
    }
}
