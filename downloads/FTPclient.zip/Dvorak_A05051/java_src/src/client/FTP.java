package client;

import java.io.IOException;
import functions.Cdup;
import functions.Connect;
import functions.Cwd;
import functions.Dele;
import functions.Help;
import functions.List;
import functions.Mkd;
import functions.Pwd;
import functions.Quit;
import functions.Raw;
import functions.Retr;

import functions.Retr;
import functions.Rmd;
import functions.Stor;

/**
 *
 * @author Tomas Dvorak, A05051
 */
public class FTP {

    Connect connection;
    String host;
    int port;
    String name;
    String pass;

    /**
     * 
     * @param host
     * @param port
     * @param name
     * @param pass
     * @throws java.io.IOException
     */
    public FTP(String host, int port, String name, String pass) throws IOException {
        this.host = host;
        this.port = port;
        this.name = name;
        this.pass = pass;


    }

    /**
     * 
     * @throws java.io.IOException
     * vytvari nove spojeni s FTP serverem
     */
    public void Connect() throws IOException {
        connection = new Connect(this.host, this.port, this.name, this.pass);
    }

    /**
     * 
     * @return aktualni pracovni slozka
     * @throws java.io.IOException
     */
    public String Pwd() throws IOException {
        Pwd p = new Pwd(connection);
        return p.vykonej();


    }

    /**
     * 
     * @return list souboru a slozek v aktualnim pracovnim adresari
     * @throws java.io.IOException
     */
    public String List() throws IOException {
        List l = new List(connection);
        return l.vykonej();
    }

    /**
     * Ukoncuje spojeni s FTP serverem
     * @return ukoncujici zprava serveru
     * @throws java.io.IOException
     */
    public String Quit() throws IOException {
        Quit q = new Quit(connection);
        return q.vykonej();
    }

    /**
     * 
     * @param slozka
     * @return true nebo false, pokud se povedla zmena pracovniho adresare
     * @throws java.io.IOException
     */
    public boolean Cwd(String slozka) throws IOException {
        Cwd cwd = new Cwd(connection, slozka);
        return cwd.vykonej();
    }

    /**
     * 
     * @param slozka
     * @return true nebo false pokud se povedla tvorba nove slozky
     * @throws java.io.IOException
     */
    public boolean Mkd(String slozka) throws IOException {
        Mkd mkd = new Mkd(connection, slozka);
        return mkd.vykonej();
    }

    /**
     * stahne soubor z FTP serveru
     * @param odkud
     * @param kam
     * @throws java.io.IOException
     * @throws java.lang.InterruptedException
     */
    public void Retr(String odkud, String kam) throws IOException, InterruptedException {
        Retr r = new Retr(connection, odkud, kam);
        r.start();
        r.join();
    }

    /**
     * ulozi soubor na server
     * @param nazev
     * @param cesta
     * @throws java.lang.InterruptedException
     */
    public void Stor(String nazev, String cesta) throws InterruptedException {
        Stor stor = new Stor(connection, nazev, cesta);

        stor.start();
        stor.join();
    }

    /**
     * odebere slozku v aktualnim pracovnim adresari
     * @param slozka
     * @throws java.io.IOException
     */
    public void Rmd(String slozka) throws IOException {
        Rmd rmd = new Rmd(connection, slozka);
        rmd.vykonej();
    }

    /**
     * smaze soubor na FTP serveru
     * @param soubor
     * @throws java.io.IOException
     */
    public void Dele(String soubor) throws IOException {
        Dele dele = new Dele(connection, soubor);
        dele.vykonej();
    }

    /**
     * vytvori a odesle cisty FTP prikaz na server
     * @param expr
     * @throws java.io.IOException
     */
    public void Raw(String expr) throws IOException {
        Raw raw = new Raw(connection, expr);
        raw.vykonej();
    }

    /**
     * zmeni aktualni pracovni adresar na adresar o uroven vyse
     * @return true/false podle toho zda se povede zmena adresare
     * @throws java.io.IOException
     */
    public boolean Cdup() throws IOException {
        Cdup cdup = new Cdup(connection);
        return cdup.vykonej();

    }

    /**
     * vypise FTP prikazy platne pro tento server
     * @return retezec s napovedou serveru 
     * @throws java.io.IOException
     */
    public String Help() throws IOException {
        Help help = new Help(connection);
        return help.vykonej();
    }

    /**
     * zpracovava frontu zprav pro/ze serveru
     * @return retezec se zpravou ze zasobniku
     */
    public String readMessages() {
        String celek = null;
        String zprava = "";
        if (connection != null) {

            while ((zprava = connection.vyberZpravu()) != null) {
                if (celek == null) {
                    celek = "";
                }
                celek = "" + celek + "\n" + zprava;
            }
        }

        return celek;
    }
}
