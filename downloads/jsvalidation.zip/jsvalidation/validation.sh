#!/bin/bash

java -cp .:bin/js.jar org.mozilla.javascript.tools.shell.Main bin/runner.js example.js
