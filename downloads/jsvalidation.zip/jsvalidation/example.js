function timeMsg() {
    var t = setTimeout("alertMsg()", 3000);
}
function alertMsg() {
    alert("Hello");
}